# [ Hash v.1.0 ]

Hash is a Hash Encryption and Hash Dencyption for easily your job 

# [ Hash feature ]
- [x] auto detect hash
- [x] fast decrypt
- [x] fast decrypt
- [x] many type hash

# [ Installation ]
```
$ apt update upgrade
$ apt install python2 git
$ pip install requirements.txt
$ git clone https://github.com/ngetest1/h4sh
$ cd h4sh
$ python2 h4sh.py
```
"Hash versi beta Jadi mohon Maaf apabila ada kesalahan"